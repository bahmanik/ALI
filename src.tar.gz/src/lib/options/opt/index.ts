import { createState } from "gnim";
import { ConfigManager } from "../configManager";
import type { DepRef, Derive, OptExports, OptProps } from "../types";
import type { Accessor } from "gnim"

type WriteOptions = { writeDisk?: boolean };

export class Opt<T = unknown, Root = unknown, Self = unknown> {
    public readonly initial: T;
    public readonly runtime: boolean;
    public readonly exports: OptExports;
    public readonly derive?: Derive<Root, Self, T>;

    private _id = "";
    private _selfRef: Self | undefined;

    private _configManager: ConfigManager;
    private _accessor: ReturnType<typeof createState<T>>[0];
    private _setter: ReturnType<typeof createState<T>>[1];

    /**
     * Dependency prefixes for derived options.
     * When any option whose id starts with one of these prefixes changes,
     * the registry recomputes this option.
     */
    public readonly deps: DepRef<Root, Self>[];

    constructor(
        initial: T,
        configManager: ConfigManager,
        {
            runtime = false,
            scss = false,
            hyprland = false,
            derive,
            deps = [],
        }: OptProps<Root, Self, T> = {}
    ) {
        this.initial = initial;

        const isDerived = typeof derive === "function";
        this.runtime = isDerived ? true : runtime;

        this.derive = derive;
        this.deps = isDerived ? deps : [];

        this._configManager = configManager;
        const [accessor, setter] = createState(initial);
        this._accessor = accessor;
        this._setter = setter;

        this.exports = {
            scss: scss ?? false,
            hyprland: hyprland ?? false,
        };
    }

    // Make Opt work like Accessor in JSX (no any)
    public as<R>(transform: (value: T) => R): Accessor<R> {
        return this._accessor(transform);
    }

    public get(): T {
        return this._accessor.peek();
    }

    public set(value: T, writeOptions: WriteOptions = {}): void {
        const requestedWriteDisk = writeOptions.writeDisk ?? true;
        const writeDisk = this.derive ? false : requestedWriteDisk;

        if (value === this._accessor.peek()) return;
        this._setter(value);

        if (writeDisk && !this.runtime) {
            this._configManager.updateOption(this._id, value);
        }
    }

    public get value(): T {
        return this.get();
    }

    public set value(val: T) {
        this.set(val);
    }

    public get id(): string {
        return this._id;
    }

    public set id(newId: string) {
        this._id = newId;
    }

    /** Internal: set by OptionRegistry during collection (used for derive({ self })). */
    public set selfRef(ref: Self | undefined) {
        this._selfRef = ref;
    }

    /** Internal: read by OptionRegistry. */
    public get selfRef(): Self | undefined {
        return this._selfRef;
    }

    public init(config: Record<string, unknown>): void {
        // Derived options never read from disk.
        if (this.derive) return;

        const value = this._configManager.getNestedValue(config, this._id);
        if (value !== undefined) this._setter(value as unknown as T);
    }

    public reset(writeOptions: WriteOptions = {}): string | undefined {
        if (this.runtime || this.derive) return;

        const current = JSON.stringify(this._accessor.peek());
        const initial = JSON.stringify(this.initial);
        if (current !== initial) {
            this.set(this.initial, writeOptions);
            return this._id;
        }
        return;
    }

    public subscribe(callback: () => void) {
        return this._accessor.subscribe(callback);
    }
}
